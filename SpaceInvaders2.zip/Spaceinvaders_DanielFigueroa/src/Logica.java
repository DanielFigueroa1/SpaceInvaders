import java.util.ArrayList;

import processing.core.PApplet;

public class Logica {
	PApplet app;
	Heroe player; // variable player que pertenece a clase heroe
	ArrayList<Invasor> enemy;
	boolean derecha,izquierda;

	public Logica(PApplet app) {
		this.app = app;

		player = new Heroe(30, 560, app);
		enemy = new ArrayList<Invasor>();
		for (int i = 0; i < 10; i++) {
			enemy.add(new Invasor(20 + (60 * i), -20, app));
			enemy.add(new Invasor(20 + (60 * i), 80, app));
			enemy.add(new Invasor(20 + (60 * i), 180, app));
		}

	}

	public void choqueBalas(ArrayList<Disparo> disparo, ArrayList<Invasor> invasor) {

		for (int i = 0; i < disparo.size(); i++) {
			for (int j = 0; j < invasor.size(); j++) {

				if (disparo.size() != 0 && app.dist(invasor.get(j).getPosX(), invasor.get(j).getPosY(),
						disparo.get(i).getPosX(), disparo.get(i).getPosY()) < 20) {

					enemy.remove(j);
					player.removeDisparo(i);

				}

			}

		}

	}

	public void choquePersonaje(Heroe personaje, ArrayList<Invasor> invasor) {

		for (int i = 0; i < invasor.size(); i++) {

			if (app.dist(personaje.getPosX(), personaje.getPosY(), invasor.get(i).getPosX(), invasor.get(i).getPosY())<20) {

				System.out.println("something");
				player.setPosY(-20);

			}

		}

	}

	public void draw() {
		player.draw();// cada metodo tiene parentesis
		choqueBalas(player.getBalas(), enemy);
		choquePersonaje(player,enemy);
		for (int i = 0; i < enemy.size(); i++) {
			enemy.get(i).draw();
			enemy.get(i).mover();

		}
		app.fill(255);
		app.textSize(15);
		app.text(enemy.size(), 550, 550);
		app.text(player.getVida(), 500, 550);
	}

	public void teclado() {

		if (app.keyCode == app.UP) {
			player.disparar();

		}
		if (app.keyCode == app.LEFT) {
			player.moverIzquierda();
		}
		if (app.keyCode == app.RIGHT) {
			player.moverDerecha();

		}
	}
}
