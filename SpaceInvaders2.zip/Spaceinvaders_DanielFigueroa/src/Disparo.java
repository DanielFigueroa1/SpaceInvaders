import processing.core.PApplet;

public class Disparo {
	
	private int posX;
	private int posY;
	private PApplet app;
	

	private int vel;
	
	public Disparo (int posX,int posY, PApplet app) { //CONSTRUCTOR
		this.posX = posX;
	    this.posY = posY;
	    this.app = app;
	    this.vel = 3;
		
	}
	
	public void mover() { //metodo o funciones
		posY-=vel;
	}
	
	public void draw() {
		app.fill(120,120,0);
		app.rect(posX,posY,10,30);
		
	}
	
	
	public int getPosX() { //gets y settes siempre van de ultimos
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}
}
