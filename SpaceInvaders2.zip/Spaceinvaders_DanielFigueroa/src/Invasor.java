import java.util.ArrayList;

import processing.core.PApplet;

public class Invasor {
	private int posX;
	private int posY;
	private PApplet app;
	private int vel;

	public Invasor (int posX,int posY,PApplet app) { //Constructor se le pasan los argumentos
		this.posX = posX;
	    this.posY = posY;
	    this.app = app;
	    this.vel = 3;
	}
	
	public void draw() {
		app.fill(255);
		app.ellipse(posX,posY,20,20);

		
	}
	
	public void mover() { //metodo o funciones
		posX+=vel;
		if (posX<0||posX>580) {
		posY+=50;
		vel*=-1;	
		}
		

	}

	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}
	
}
