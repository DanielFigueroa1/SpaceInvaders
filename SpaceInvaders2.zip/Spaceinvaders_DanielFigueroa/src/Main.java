

import processing.core.PApplet;

public class Main extends PApplet {
	
public static void main(String[] args) {
		
		PApplet.main("Main"); // no s� como es pero debo hacerlo

	}

	Logica logica; //variable de clase Logica llamada "logica"

	public void settings() {
		size (600,600);
		
	}
	
	public void setup() {
		logica = new Logica(this);
		
	}
	
	public void draw() {
		background(0);
		logica.draw();
		
	}
	
	public void keyPressed() {
		logica.teclado();
	}
}
