import java.util.ArrayList;

import processing.core.PApplet;

public class Heroe {
	private int posX;
	private int posY;
	private PApplet app;
	private int vel;
	private int vida;
	private ArrayList<Disparo> balas;

	public Heroe(int posX, int posY, PApplet app) { // Constructor se le pasan los argumentos
		this.posX = posX;
		this.posY = posY;
		this.app = app;
		this.vel = 5;
		this.vida = 3;
		this.balas = new ArrayList<Disparo>(); // variable/arraylist balas que pertence a la clase disparo
	}

	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public void moverIzquierda() { // metodo o funciones
		if (posX > 0 && posX < 580) {
			posX -= vel;
		}

	}

	public void moverDerecha() { // metodo o funciones
		if (posX > 0 && posX < 580) {
			posX += vel;
		}

	}

	public void draw() {
		app.fill(255);
		app.rect(posX, posY, 20, 20);
		for (int i = 0; i < balas.size(); i++) {

			balas.get(i).draw();
			balas.get(i).mover();
			if (balas.get(i).getPosY() < 0) {
				balas.remove(i);
			}
		}

	}

	public void disparar() {
		balas.add(new Disparo(posX, posY, app));

	}

	public void removeDisparo(int i) {
		balas.remove(i);
	}

	public ArrayList<Disparo> getBalas() {
		return balas;
	}

	public void setBalas(ArrayList<Disparo> balas) {
		this.balas = balas;
	}

	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}

}
